create materialized view abbreviatepresentationofordersmaterialized as
SELECT orderdate,
       ordertime,
       customername,
       customerphone,
       menuitem1,
       menuitem2,
       menuitem3,
       price,
       completionmark,
       employeename
FROM abbreviatepresentationoforders o;

alter materialized view abbreviatepresentationofordersmaterialized owner to postgres;

create index idx_simple_order_details
    on abbreviatepresentationofordersmaterialized (orderdate, completionmark);

