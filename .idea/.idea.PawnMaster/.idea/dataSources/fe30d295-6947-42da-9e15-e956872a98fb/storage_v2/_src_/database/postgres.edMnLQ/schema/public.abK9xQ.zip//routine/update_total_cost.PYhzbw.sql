create function update_total_cost() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE Warehouse
    SET Cost = NEW.Cost
    WHERE Ingredient_ID = NEW.Ingredient_ID;
    RETURN NEW;
END;
$$;

alter function update_total_cost() owner to postgres;

