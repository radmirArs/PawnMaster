create view orderdetails
            (orderdate, ordertime, customername, customerphone, menuitem1, menuitem2, menuitem3, price, completionmark,
             employeename)
as
SELECT o.orderdate,
       o.ordertime,
       o.customername,
       o.customerphone,
       m1.menuitemname AS menuitem1,
       m2.menuitemname AS menuitem2,
       m3.menuitemname AS menuitem3,
       o.price,
       o.completionmark,
       e.fullname      AS employeename
FROM orders o
         LEFT JOIN menu m1 ON o.menuitem_id1 = m1.menuitem_id
         LEFT JOIN menu m2 ON o.menuitem_id2 = m2.menuitem_id
         LEFT JOIN menu m3 ON o.menuitem_id3 = m3.menuitem_id
         LEFT JOIN employees e ON o.employee_id = e.employee_id;

alter table orderdetails
    owner to postgres;

