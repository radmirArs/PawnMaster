create view menudetails
            (menuitem_id, menuitemname, ingredient1, volume＿id1, ingredient2, volume_id2, ingredient3, volume_id3,
             price, cookingtime)
as
SELECT m.menuitem_id,
       m.menuitemname,
       w1.ingredientname AS ingredient1,
       m."volume＿id1",
       w2.ingredientname AS ingredient2,
       m.volume_id2,
       w3.ingredientname AS ingredient3,
       m.volume_id3,
       m.price,
       m.cookingtime
FROM menu m
         LEFT JOIN warehouse w1 ON m.ingredient_id1 = w1.ingredient_id
         LEFT JOIN warehouse w2 ON m.ingredient_id2 = w2.ingredient_id
         LEFT JOIN warehouse w3 ON m.ingredient_id3 = w3.ingredient_id;

alter table menudetails
    owner to postgres;

