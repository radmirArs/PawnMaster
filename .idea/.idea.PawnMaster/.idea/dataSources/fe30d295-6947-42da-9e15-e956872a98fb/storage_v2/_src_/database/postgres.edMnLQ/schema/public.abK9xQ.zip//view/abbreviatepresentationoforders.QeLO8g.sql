create view abbreviatepresentationoforders
            (orderdate, ordertime, customername, customerphone, menuitem1, menuitem2, menuitem3, price, completionmark,
             employeename)
as
SELECT orderdate,
       ordertime,
       customername,
       customerphone,
       menuitem1,
       menuitem2,
       menuitem3,
       price,
       completionmark,
       employeename
FROM orderdetails o;

alter table abbreviatepresentationoforders
    owner to postgres;

