create procedure change_status_cook(IN p_order_id integer, IN p_new_statuc_cook character varying)
    language plpgsql
as
$$
    BEGIN
        UPDATE Orders 
        set completionmark = p_new_statuc_cook
        WHERE Order_ID = p_order_ID;
    end;
    $$;

alter procedure change_status_cook(integer, varchar) owner to postgres;

