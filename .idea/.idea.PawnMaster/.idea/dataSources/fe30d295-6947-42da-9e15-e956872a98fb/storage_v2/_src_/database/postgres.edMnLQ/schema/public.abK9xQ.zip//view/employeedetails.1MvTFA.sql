create view employeedetails (employee_id, fullname, age, gender, address, phone, passportinfo, positionname, salary) as
SELECT e.employee_id,
       e.fullname,
       e.age,
       e.gender,
       e.address,
       e.phone,
       e.passportinfo,
       p.positionname,
       p.salary
FROM employees e
         JOIN positions p ON e.position_id = p.position_id;

alter table employeedetails
    owner to postgres;

