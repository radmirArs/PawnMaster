create function add_order() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE NOTICE 'New order added: ID = %, Customer = %, Date = %, Amount = %', 
        NEW.CUSTOMERNAME, NEW.CUSTOMERNAME, NEW.ORDERDATE, NEW.ORDERTIME;
    RETURN NEW;
END;
$$;

alter function add_order() owner to postgres;

