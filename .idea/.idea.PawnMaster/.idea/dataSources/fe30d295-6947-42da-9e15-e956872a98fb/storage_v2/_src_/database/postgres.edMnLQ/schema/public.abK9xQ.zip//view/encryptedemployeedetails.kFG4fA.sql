create view encryptedemployeedetails
            (employee_id, encryptedfullname, age, gender, encryptedaddress, encryptedphone, encryptedpassportinfo,
             positionname, salary)
as
SELECT employee_id,
       encode(fullname::bytea, 'base64'::text)     AS encryptedfullname,
       age,
       gender,
       encode(address::bytea, 'base64'::text)      AS encryptedaddress,
       encode(phone::bytea, 'base64'::text)        AS encryptedphone,
       encode(passportinfo::bytea, 'base64'::text) AS encryptedpassportinfo,
       positionname,
       salary
FROM employeedetails;

alter table encryptedemployeedetails
    owner to postgres;

