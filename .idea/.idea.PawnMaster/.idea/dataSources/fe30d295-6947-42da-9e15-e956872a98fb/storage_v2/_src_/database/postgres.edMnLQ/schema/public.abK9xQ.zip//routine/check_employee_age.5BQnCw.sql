create function check_employee_age() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.Age < 16 THEN
        RAISE EXCEPTION 'Сотрудник младше 16 лет';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_employee_age() owner to postgres;

